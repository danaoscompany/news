<?php
$c = new mysqli("localhost", "news", "HelloWorld@123");
$c->select_db("news");
