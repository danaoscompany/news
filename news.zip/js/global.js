const HOST = "prakuliah.000webhostapp.com/news";
const PHP_URL = "http://"+HOST+"/php/";